'use client';

import { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  Instagram, 
  Youtube, 
  Twitter, 
  Facebook, 
  Video, 
  Linkedin,
  ArrowLeft,
  ShoppingCart,
  CheckCircle,
  Star,
  MessageCircle
} from 'lucide-react';

interface Package {
  id: string;
  name: string;
  platform: string;
  quantity: number;
  price: number;
  description?: string;
  isActive: boolean;
}

const platformIcons = {
  Instagram,
  Youtube,
  Twitter,
  Facebook,
  TikTok: Video,
  LinkedIn: Linkedin,
};

export default function OrderPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [packages, setPackages] = useState<Package[]>([]);
  const [selectedPlatform, setSelectedPlatform] = useState('');
  const [selectedPackage, setSelectedPackage] = useState<Package | null>(null);
  const [targetUsername, setTargetUsername] = useState('');
  const [targetUrl, setTargetUrl] = useState('');
  const [notes, setNotes] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (status === 'loading') return;
    
    if (!session) {
      router.push('/login');
      return;
    }

    fetchPackages();
  }, [session, status, router]);

  const fetchPackages = async () => {
    try {
      const response = await fetch('/api/packages');
      if (response.ok) {
        const data = await response.json();
        setPackages(data.packages || []);
      }
    } catch (error) {
      console.error('Failed to fetch packages:', error);
    } finally {
      setLoading(false);
    }
  };

  const handlePlatformChange = (platform: string) => {
    setSelectedPlatform(platform);
    setSelectedPackage(null);
  };

  const handlePackageSelect = (pkg: Package) => {
    setSelectedPackage(pkg);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedPackage || !targetUsername) {
      alert('Silakan pilih paket dan masukkan username target');
      return;
    }

    setIsLoading(true);

    try {
      const response = await fetch('/api/orders', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          packageId: selectedPackage.id,
          packageName: selectedPackage.name,
          platform: selectedPackage.platform,
          targetUrl,
          targetUsername,
          quantity: selectedPackage.quantity,
          price: selectedPackage.price,
          notes,
        }),
      });

      if (response.ok) {
        alert('Order berhasil dibuat! Admin akan segera memproses order Anda.');
        router.push('/dashboard');
      } else {
        const data = await response.json();
        alert(data.error || 'Gagal membuat order');
      }
    } catch (error) {
      console.error('Order creation failed:', error);
      alert('Terjadi kesalahan. Silakan coba lagi.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleWhatsAppContact = () => {
    window.open('https://wa.me/6283176771027', '_blank');
  };

  const platforms = Array.from(new Set(packages.map(pkg => pkg.platform)));
  const filteredPackages = packages.filter(pkg => pkg.platform === selectedPlatform);

  if (status === 'loading' || loading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-white">Loading...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black">
      {/* Header */}
      <header className="sticky top-0 z-50 backdrop-blur-lg bg-opacity-90 border-b border-gray-800">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Link href="/dashboard" className="flex items-center space-x-2">
                <Button variant="ghost" className="text-gray-300 hover:text-blue-500">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Kembali
                </Button>
              </Link>
              <h1 className="text-xl font-bold text-blue-500">Order Followers</h1>
            </div>
            
            <Button 
              onClick={handleWhatsAppContact}
              variant="outline"
              className="border-green-500 text-green-500 hover:bg-green-500 hover:text-white"
            >
              <MessageCircle className="w-4 h-4 mr-2" />
              Support
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Package Selection */}
          <div>
            <h2 className="text-2xl font-bold text-white mb-6">Pilih Paket Followers</h2>
            
            {/* Platform Selection */}
            <div className="mb-6">
              <Label className="text-gray-300 mb-2 block">Platform</Label>
              <Select value={selectedPlatform} onValueChange={handlePlatformChange}>
                <SelectTrigger className="bg-gray-900 border-gray-700 text-white">
                  <SelectValue placeholder="Pilih platform" />
                </SelectTrigger>
                <SelectContent className="bg-gray-900 border-gray-700">
                  {platforms.map((platform) => {
                    const Icon = platformIcons[platform as keyof typeof platformIcons];
                    return (
                      <SelectItem key={platform} value={platform} className="text-white">
                        <div className="flex items-center gap-2">
                          {Icon && <Icon className="w-4 h-4" />}
                          {platform}
                        </div>
                      </SelectItem>
                    );
                  })}
                </SelectContent>
              </Select>
            </div>

            {/* Package Cards */}
            <div className="space-y-4">
              {filteredPackages.map((pkg) => (
                <Card 
                  key={pkg.id}
                  className={`bg-gray-900 border-gray-800 cursor-pointer transition-all ${
                    selectedPackage?.id === pkg.id 
                      ? 'ring-2 ring-blue-500 bg-gray-800' 
                      : 'hover:bg-gray-800'
                  }`}
                  onClick={() => handlePackageSelect(pkg)}
                >
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-white">{pkg.name}</CardTitle>
                      <Badge className="bg-blue-500 text-white">
                        {pkg.platform}
                      </Badge>
                    </div>
                    <CardDescription className="text-gray-400">
                      {pkg.description}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-2xl font-bold text-blue-500">
                          {pkg.quantity.toLocaleString()}
                        </div>
                        <div className="text-sm text-gray-400">Followers</div>
                      </div>
                      <div className="text-right">
                        <div className="text-2xl font-bold text-white">
                          Rp {pkg.price.toLocaleString('id-ID')}
                        </div>
                        {pkg.quantity > 5000 && (
                          <Badge className="bg-green-500 text-white text-xs mt-1">
                            <Star className="w-3 h-3 mr-1" />
                            Best Value
                          </Badge>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {selectedPlatform && filteredPackages.length === 0 && (
              <div className="text-center py-8">
                <ShoppingCart className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                <p className="text-gray-400">Tidak ada paket tersedia untuk platform ini</p>
              </div>
            )}
          </div>

          {/* Order Form */}
          <div>
            <h2 className="text-2xl font-bold text-white mb-6">Detail Order</h2>
            
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader>
                <CardTitle className="text-white">Informasi Target</CardTitle>
                <CardDescription className="text-gray-400">
                  Masukkan informasi akun target followers
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-4">
                  {/* Selected Package Info */}
                  {selectedPackage && (
                    <div className="bg-blue-500/20 border border-blue-500 rounded-lg p-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="text-white font-semibold">{selectedPackage.name}</h4>
                          <p className="text-gray-400 text-sm">
                            {selectedPackage.quantity.toLocaleString()} followers • {selectedPackage.platform}
                          </p>
                        </div>
                        <div className="text-xl font-bold text-blue-500">
                          Rp {selectedPackage.price.toLocaleString('id-ID')}
                        </div>
                      </div>
                    </div>
                  )}

                  <div className="space-y-2">
                    <Label htmlFor="username" className="text-gray-300">
                      Username Target *
                    </Label>
                    <Input
                      id="username"
                      type="text"
                      placeholder="contoh: username_tanpa_@"
                      value={targetUsername}
                      onChange={(e) => setTargetUsername(e.target.value)}
                      className="bg-gray-800 border-gray-700 text-white"
                      required
                    />
                    <p className="text-xs text-gray-500">
                      Masukkan username tanpa simbol @
                    </p>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="url" className="text-gray-300">
                      URL Profile (Opsional)
                    </Label>
                    <Input
                      id="url"
                      type="url"
                      placeholder="https://instagram.com/username"
                      value={targetUrl}
                      onChange={(e) => setTargetUrl(e.target.value)}
                      className="bg-gray-800 border-gray-700 text-white"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="notes" className="text-gray-300">
                      Catatan (Opsional)
                    </Label>
                    <Textarea
                      id="notes"
                      placeholder="Catatan khusus untuk order ini..."
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      className="bg-gray-800 border-gray-700 text-white"
                      rows={3}
                    />
                  </div>

                  <div className="bg-gray-800 rounded-lg p-4">
                    <h4 className="text-white font-semibold mb-2">📝 Catatan Penting:</h4>
                    <ul className="text-gray-400 text-sm space-y-1">
                      <li>• Pastikan akun target tidak di-private</li>
                      <li>• Username yang dimasukkan harus benar</li>
                      <li>• Proses biasanya memakan waktu 1-24 jam</li>
                      <li>• Jika ada masalah, hubungi admin via WhatsApp</li>
                    </ul>
                  </div>

                  <Button
                    type="submit"
                    className="w-full btn-3d bg-blue-500 hover:bg-blue-600 text-white"
                    disabled={!selectedPackage || !targetUsername || isLoading}
                  >
                    {isLoading ? 'Memproses...' : 'Buat Order Sekarang'}
                  </Button>

                  <div className="text-center">
                    <Button
                      type="button"
                      variant="outline"
                      className="border-green-500 text-green-500 hover:bg-green-500 hover:text-white"
                      onClick={handleWhatsAppContact}
                    >
                      <MessageCircle className="w-4 h-4 mr-2" />
                      Butuh Bantuan? Hubungi Admin
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}