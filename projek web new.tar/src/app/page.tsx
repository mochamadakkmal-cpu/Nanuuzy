'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { 
  Instagram, 
  Youtube, 
  Twitter, 
  Facebook, 
  Video, 
  Linkedin,
  MessageCircle,
  Phone,
  HelpCircle,
  Star,
  TrendingUp,
  Users,
  Shield,
  Zap,
  CheckCircle,
  ArrowRight,
  Sun,
  Moon
} from 'lucide-react';

export default function Home() {
  const [isDarkMode, setIsDarkMode] = useState(true);

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.remove('light');
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
      document.documentElement.classList.add('light');
    }
  }, [isDarkMode]);

  const packages = [
    {
      platform: 'Instagram',
      icon: Instagram,
      packages: [
        { name: 'Starter', followers: 1000, price: 50000, popular: false },
        { name: 'Professional', followers: 5000, price: 200000, popular: true },
        { name: 'Business', followers: 10000, price: 350000, popular: false },
      ]
    },
    {
      platform: 'TikTok',
      icon: Video,
      packages: [
        { name: 'Basic', followers: 1000, price: 45000, popular: false },
        { name: 'Popular', followers: 5000, price: 180000, popular: true },
        { name: 'Viral', followers: 10000, price: 300000, popular: false },
      ]
    },
    {
      platform: 'YouTube',
      icon: Youtube,
      packages: [
        { name: 'Starter', followers: 500, price: 75000, popular: false },
        { name: 'Creator', followers: 2000, price: 250000, popular: true },
        { name: 'Influencer', followers: 5000, price: 500000, popular: false },
      ]
    },
    {
      platform: 'Twitter',
      icon: Twitter,
      packages: [
        { name: 'Basic', followers: 1000, price: 40000, popular: false },
        { name: 'Trending', followers: 5000, price: 150000, popular: true },
        { name: 'Viral', followers: 10000, price: 250000, popular: false },
      ]
    }
  ];

  const features = [
    {
      icon: Shield,
      title: '100% Aman',
      description: 'Metode aman tanpa password, akun Anda tetap terlindungi'
    },
    {
      icon: Zap,
      title: 'Proses Cepat',
      description: 'Pemesanan instan dan proses cepat dalam hitungan menit'
    },
    {
      icon: Users,
      title: 'Followers Aktif',
      description: 'Followers real dan aktif dari berbagai negara'
    },
    {
      icon: TrendingUp,
      title: 'Garansi',
      description: 'Garansi penggantian jika followers drop'
    }
  ];

  const handleWhatsAppContact = () => {
    window.open('https://wa.me/6283176771027', '_blank');
  };

  return (
    <div className={`min-h-screen ${isDarkMode ? 'bg-black' : 'bg-white'} transition-colors duration-300`}>
      {/* Header */}
      <header className="sticky top-0 z-50 backdrop-blur-lg bg-opacity-90 border-b border-gray-800">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-10 h-10 bg-blue-500 rounded-lg flex items-center justify-center">
                <Users className="w-6 h-6 text-white" />
              </div>
              <h1 className={`text-2xl font-bold ${isDarkMode ? 'text-blue-500' : 'text-blue-600'}`}>
                NanuuzyStore Official
              </h1>
            </div>
            
            <nav className="hidden md:flex items-center space-x-6">
              <a href="#packages" className={`${isDarkMode ? 'text-gray-300 hover:text-blue-500' : 'text-gray-700 hover:text-blue-600'} transition-colors`}>
                Paket
              </a>
              <a href="#features" className={`${isDarkMode ? 'text-gray-300 hover:text-blue-500' : 'text-gray-700 hover:text-blue-600'} transition-colors`}>
                Fitur
              </a>
              <a href="#contact" className={`${isDarkMode ? 'text-gray-300 hover:text-blue-500' : 'text-gray-700 hover:text-blue-600'} transition-colors`}>
                Kontak
              </a>
            </nav>

            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Sun className={`w-4 h-4 ${isDarkMode ? 'text-gray-500' : 'text-yellow-500'}`} />
                <Switch
                  checked={isDarkMode}
                  onCheckedChange={setIsDarkMode}
                  className="data-[state=checked]:bg-blue-600"
                />
                <Moon className={`w-4 h-4 ${isDarkMode ? 'text-blue-400' : 'text-gray-400'}`} />
              </div>
              
              <Link href="/login">
                <Button variant="outline" className="border-blue-500 text-blue-500 hover:bg-blue-500 hover:text-white">
                  Masuk
                </Button>
              </Link>
              
              <Link href="/register">
                <Button className="btn-3d bg-blue-500 hover:bg-blue-600 text-white">
                  Daftar
                </Button>
              </Link>
              
              <Button 
                onClick={handleWhatsAppContact}
                className="btn-3d bg-green-500 hover:bg-green-600 text-white"
              >
                <MessageCircle className="w-4 h-4 mr-2" />
                WhatsApp
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative overflow-hidden py-20 px-4">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-900/20 to-purple-900/20"></div>
        <div className="relative container mx-auto text-center">
          <div className="fade-in">
            <Badge className="mb-4 bg-blue-500 text-white px-4 py-2">
              <Star className="w-4 h-4 mr-2" />
              Platform Reseller Terpercaya
            </Badge>
            
            <h1 className={`text-5xl md:text-7xl font-bold mb-6 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
              Jual Beli Followers
              <span className="block text-blue-500">Semua Social Media</span>
            </h1>
            
            <p className={`text-xl md:text-2xl mb-8 ${isDarkMode ? 'text-gray-300' : 'text-gray-600'}`}>
              Platform reseller terpercaya untuk meningkatkan followers Anda
              <br />
              Instagram, TikTok, YouTube, Twitter & lainnya
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg"
                className="btn-3d bg-blue-500 hover:bg-blue-600 text-white px-8 py-4 text-lg"
                onClick={() => document.getElementById('packages')?.scrollIntoView({ behavior: 'smooth' })}
              >
                <TrendingUp className="w-5 h-5 mr-2" />
                Lihat Paket
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
              
              <Button 
                size="lg"
                variant="outline"
                className="btn-3d border-blue-500 text-blue-500 hover:bg-blue-500 hover:text-white px-8 py-4 text-lg"
                onClick={handleWhatsAppContact}
              >
                <Phone className="w-5 h-5 mr-2" />
                Hubungi Admin
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 px-4">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className={`text-4xl font-bold mb-4 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
              Mengapa Memilih NanuuzyStore?
            </h2>
            <p className={`text-xl ${isDarkMode ? 'text-gray-300' : 'text-gray-600'}`}>
              Keunggulan yang membuat kami berbeda dari yang lain
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, index) => (
              <Card key={index} className={`card-3d ${isDarkMode ? 'bg-gray-900 border-gray-800' : 'bg-white border-gray-200'}`}>
                <CardHeader className="text-center">
                  <div className="w-16 h-16 bg-blue-500 rounded-full flex items-center justify-center mx-auto mb-4">
                    <feature.icon className="w-8 h-8 text-white" />
                  </div>
                  <CardTitle className={isDarkMode ? 'text-white' : 'text-gray-900'}>
                    {feature.title}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className={`text-center ${isDarkMode ? 'text-gray-300' : 'text-gray-600'}`}>
                    {feature.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Packages Section */}
      <section id="packages" className="py-20 px-4">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className={`text-4xl font-bold mb-4 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
              Paket Followers Terbaik
            </h2>
            <p className={`text-xl ${isDarkMode ? 'text-gray-300' : 'text-gray-600'}`}>
              Pilih paket yang sesuai dengan kebutuhan Anda
            </p>
          </div>
          
          <div className="space-y-12">
            {packages.map((platform, platformIndex) => (
              <div key={platformIndex} className="slide-in-left">
                <div className="flex items-center mb-6">
                  <platform.icon className="w-8 h-8 text-blue-500 mr-3" />
                  <h3 className={`text-2xl font-bold ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                    {platform.platform}
                  </h3>
                </div>
                
                <div className="grid md:grid-cols-3 gap-6">
                  {platform.packages.map((pkg, pkgIndex) => (
                    <Card key={pkgIndex} className={`card-3d relative ${isDarkMode ? 'bg-gray-900 border-gray-800' : 'bg-white border-gray-200'} ${pkg.popular ? 'ring-2 ring-blue-500' : ''}`}>
                      {pkg.popular && (
                        <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                          <Badge className="bg-blue-500 text-white px-3 py-1">
                            <Star className="w-3 h-3 mr-1" />
                            Populer
                          </Badge>
                        </div>
                      )}
                      
                      <CardHeader className="text-center">
                        <CardTitle className={`text-xl ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
                          {pkg.name}
                        </CardTitle>
                        <div className="text-3xl font-bold text-blue-500">
                          {pkg.followers.toLocaleString()}
                        </div>
                        <CardDescription className={isDarkMode ? 'text-gray-400' : 'text-gray-600'}>
                          Followers
                        </CardDescription>
                      </CardHeader>
                      
                      <CardContent className="text-center">
                        <div className="text-2xl font-bold mb-4">
                          Rp {pkg.price.toLocaleString('id-ID')}
                        </div>
                        
                        <Button 
                          className="btn-3d w-full bg-blue-500 hover:bg-blue-600 text-white"
                          onClick={handleWhatsAppContact}
                        >
                          <CheckCircle className="w-4 h-4 mr-2" />
                          Order Sekarang
                        </Button>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 px-4">
        <div className="container mx-auto text-center">
          <div className="max-w-2xl mx-auto">
            <h2 className={`text-4xl font-bold mb-4 ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>
              Butuh Bantuan?
            </h2>
            <p className={`text-xl mb-8 ${isDarkMode ? 'text-gray-300' : 'text-gray-600'}`}>
              Hubungi admin kami untuk konsultasi dan pemesanan
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg"
                onClick={handleWhatsAppContact}
                className="btn-3d bg-green-500 hover:bg-green-600 text-white px-8 py-4"
              >
                <MessageCircle className="w-5 h-5 mr-2" />
                WhatsApp Admin
              </Button>
              
              <Button 
                size="lg"
                variant="outline"
                className="btn-3d border-blue-500 text-blue-500 hover:bg-blue-500 hover:text-white px-8 py-4"
              >
                <HelpCircle className="w-5 h-5 mr-2" />
                Bantuan Developer
              </Button>
            </div>
            
            <div className={`mt-8 p-6 rounded-lg ${isDarkMode ? 'bg-gray-900' : 'bg-gray-100'}`}>
              <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                📱 WhatsApp: 0831-7677-1027
              </p>
              <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                🕐 Jam Operasional: 09:00 - 22:00 WIB
              </p>
              <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                💰 Pembayaran: Transfer Bank, E-Wallet
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className={`border-t ${isDarkMode ? 'bg-gray-900 border-gray-800' : 'bg-gray-100 border-gray-200'} py-8 px-4`}>
        <div className="container mx-auto text-center">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <div className="w-8 h-8 bg-blue-500 rounded-lg flex items-center justify-center">
              <Users className="w-5 h-5 text-white" />
            </div>
            <h3 className={`text-xl font-bold ${isDarkMode ? 'text-blue-500' : 'text-blue-600'}`}>
              NanuuzyStore Official
            </h3>
          </div>
          
          <p className={`text-sm ${isDarkMode ? 'text-gray-400' : 'text-gray-600'}`}>
            © 2024 NanuuzyStore Official. Platform Reseller Followers Terpercaya.
          </p>
          
          <div className="flex justify-center space-x-4 mt-4">
            <Button variant="ghost" size="sm" className={isDarkMode ? 'text-gray-400 hover:text-blue-500' : 'text-gray-600 hover:text-blue-600'}>
              <Instagram className="w-4 h-4" />
            </Button>
            <Button variant="ghost" size="sm" className={isDarkMode ? 'text-gray-400 hover:text-blue-500' : 'text-gray-600 hover:text-blue-600'}>
              <Video className="w-4 h-4" />
            </Button>
            <Button variant="ghost" size="sm" className={isDarkMode ? 'text-gray-400 hover:text-blue-500' : 'text-gray-600 hover:text-blue-600'}>
              <Youtube className="w-4 h-4" />
            </Button>
            <Button variant="ghost" size="sm" className={isDarkMode ? 'text-gray-400 hover:text-blue-500' : 'text-gray-600 hover:text-blue-600'}>
              <Twitter className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </footer>
    </div>
  );
}