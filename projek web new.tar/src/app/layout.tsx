import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { Providers } from "@/components/providers";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "NanuuzyStore Official - Jual Beli Followers Social Media",
  description: "Platform reseller terpercaya untuk jual beli followers semua sosial media. Instagram, TikTok, Twitter, YouTube dan lainnya.",
  keywords: ["NanuuzyStore", "followers", "social media", "Instagram", "TikTok", "Twitter", "YouTube", "reseller"],
  authors: [{ name: "NanuuzyStore Official" }],
  icons: {
    icon: "/logo.svg",
  },
  openGraph: {
    title: "NanuuzyStore Official",
    description: "Platform reseller terpercaya untuk jual beli followers semua sosial media",
    url: "https://nanuuzystore.com",
    siteName: "NanuuzyStore Official",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "NanuuzyStore Official",
    description: "Platform reseller terpercaya untuk jual beli followers semua sosial media",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        <Providers>
          {children}
          <Toaster />
        </Providers>
      </body>
    </html>
  );
}
