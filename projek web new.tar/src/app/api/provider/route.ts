import { NextRequest, NextResponse } from 'next/server';
import { auth } from '@/lib/auth';
import { db } from '@/lib/db';

export async function POST(request: NextRequest) {
  try {
    const session = await auth();
    
    if (!session?.user?.id || session.user.role !== 'ADMIN') {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const { orderId } = await request.json();

    if (!orderId) {
      return NextResponse.json(
        { error: 'Order ID is required' },
        { status: 400 }
      );
    }

    const order = await db.order.findUnique({
      where: { id: orderId },
      include: {
        user: true,
        service: true
      }
    });

    if (!order) {
      return NextResponse.json(
        { error: 'Order not found' },
        { status: 404 }
      );
    }

    if (!order.serviceId) {
      return NextResponse.json(
        { error: 'No service configured for this order' },
        { status: 400 }
      );
    }

    // Send order to provider API
    try {
      const response = await fetch(order.service.apiEndpoint!, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${order.service.apiKey}`,
        },
        body: JSON.stringify({
          service_id: order.serviceId,
          target: order.targetUsername,
          quantity: order.quantity,
          custom_data: {
            order_id: order.id,
            package_name: order.packageName,
            platform: order.platform,
            customer_email: order.user.email,
            customer_name: order.user.name,
          }
        }),
      });

      if (!response.ok) {
        throw new Error('Provider API error');
      }

      const result = await response.json();
      
      // Update order with provider response
      await db.order.update({
        where: { id: orderId },
        data: {
          status: 'PROCESSING',
          resellerOrderId: result.order_id || result.id,
          resellerApiUrl: order.service.apiEndpoint,
        }
      });

      // Update order with provider response if available
      if (result.status) {
        await db.order.update({
          where: { id: orderId },
          data: {
            status: result.status === 'success' ? 'COMPLETED' : 'FAILED',
          }
        });
      }

      return NextResponse.json({
        success: true,
        message: 'Order sent to provider successfully',
        providerResponse: result
      });

    } catch (error) {
      console.error('Provider API error:', error);
      
      // Update order status to failed
      await db.order.update({
        where: { id: orderId },
        data: {
          status: 'FAILED',
        }
      });

      return NextResponse.json({
        success: false,
        error: error.message
      });
    }
  } catch (error) {
    console.error('Provider route error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}