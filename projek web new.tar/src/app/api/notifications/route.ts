import { NextRequest, NextResponse } from 'next/server';
import { auth } from '@/lib/auth';
import { db } from '@/lib/db';
import NotificationService from '@/lib/notifications';

export async function POST(request: NextRequest) {
  try {
    const session = await auth();
    
    if (!session?.user?.id || session.user.role !== 'ADMIN') {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const { orderId, action } = await request.json();

    if (!orderId) {
      return NextResponse.json(
        { error: 'Order ID is required' },
        { status: 400 }
      );
    }

    const order = await db.order.findUnique({
      where: { id: orderId },
      include: {
        user: {
          select: {
            name: true,
            email: true
          }
        }
      }
    });

    if (!order) {
      return NextResponse.json(
        { error: 'Order not found' },
        { status: 404 }
      );
    }

    // Get service configuration for this order
    const service = order.serviceId ? await db.service.findUnique({
      where: { id: order.serviceId }
    }) : null;

    const serviceConfig = service ? {
      serviceId: service.serviceId || undefined,
      apiKey: service.apiKey || undefined,
      apiEndpoint: service.apiEndpoint || undefined,
    } : undefined;

    const notificationService = new NotificationService();
    
    if (action === 'send') {
      const result = await notificationService.sendOrderNotification({
        orderId: order.id,
        packageName: order.packageName,
        platform: order.platform,
        targetUsername: order.targetUsername,
        quantity: order.quantity,
        price: order.price,
        userEmail: order.user.email,
        userName: order.user.name || undefined,
      }, serviceConfig);

      return NextResponse.json(result);
    }

    return NextResponse.json(
      { error: 'Invalid action' },
      { status: 400 }
    );
  } catch (error) {
    console.error('Notification error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}