import { NextRequest, NextResponse } from 'next/server';
import { auth } from '@/lib/auth';
import { db } from '@/lib/db';
import NotificationService from '@/lib/notifications';

export async function GET(request: NextRequest) {
  try {
    const session = await auth();
    
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const orders = await db.order.findMany({
      where: {
        userId: session.user.id
      },
      orderBy: {
        createdAt: 'desc'
      }
    });

    return NextResponse.json({ orders });
  } catch (error) {
    console.error('Failed to fetch orders:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await auth();
    
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const {
      packageId,
      packageName,
      platform,
      targetUrl,
      targetUsername,
      quantity,
      price,
      notes
    } = await request.json();

    if (!packageId || !packageName || !platform || !targetUsername || !quantity || !price) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      );
    }

    const order = await db.order.create({
      data: {
        userId: session.user.id,
        packageId,
        packageName,
        platform,
        targetUrl: targetUrl || '',
        targetUsername,
        quantity,
        price,
        notes: notes || null,
        status: 'PENDING'
      }
    });

    // Send notification to admin
    try {
      const notificationService = new NotificationService();
      await notificationService.sendOrderNotification({
        orderId: order.id,
        packageName: order.packageName,
        platform: order.platform,
        targetUsername: order.targetUsername,
        quantity: order.quantity,
        price: order.price,
        userEmail: session.user.email || '',
        userName: session.user.name || undefined,
      });
    } catch (notificationError) {
      console.error('Failed to send notification:', notificationError);
    }

    return NextResponse.json(
      { 
        message: 'Order created successfully',
        order
      },
      { status: 201 }
    );
  } catch (error) {
    console.error('Failed to create order:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}