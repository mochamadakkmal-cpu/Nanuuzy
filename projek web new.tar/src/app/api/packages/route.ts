import { NextRequest, NextResponse } from 'next/server';
import { auth } from '@/lib/auth';
import { db } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const packages = await db.package.findMany({
      where: {
        isActive: true
      },
      orderBy: [
        { platform: 'asc' },
        { quantity: 'asc' }
      ]
    });

    return NextResponse.json({ packages });
  } catch (error) {
    console.error('Failed to fetch packages:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await auth();
    
    if (!session?.user?.id || session.user.role !== 'ADMIN') {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const {
      name,
      platform,
      quantity,
      price,
      description
    } = await request.json();

    if (!name || !platform || !quantity || !price) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      );
    }

    const newPackage = await db.package.create({
      data: {
        name,
        platform,
        quantity,
        price,
        description: description || null,
      }
    });

    return NextResponse.json(
      { 
        message: 'Package created successfully',
        package: newPackage
      },
      { status: 201 }
    );
  } catch (error) {
    console.error('Failed to create package:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}