import nodemailer from 'nodemailer';
import ZAI from 'z-ai-web-dev-sdk';

interface OrderNotificationData {
  orderId: string;
  packageName: string;
  platform: string;
  targetUsername: string;
  quantity: number;
  price: number;
  userEmail: string;
  userName?: string;
}

interface ServiceConfig {
  serviceId?: string;
  apiKey?: string;
  apiEndpoint?: string;
}

class NotificationService {
  private emailTransporter: nodemailer.Transporter;

  constructor() {
    this.emailTransporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST || 'smtp.gmail.com',
      port: parseInt(process.env.SMTP_PORT || '587'),
      secure: process.env.SMTP_SECURE === 'true',
      auth: {
        user: process.env.SMTP_USER || '',
        pass: process.env.SMTP_PASS || '',
      },
    });
  }

  async sendOrderNotification(orderData: OrderNotificationData, serviceConfig?: ServiceConfig) {
    try {
      // Send email notification
      await this.sendEmailNotification(orderData);
      
      // Send WhatsApp notification
      await this.sendWhatsAppNotification(orderData);
      
      // Send order to provider API if configured
      if (serviceConfig?.serviceId && serviceConfig?.apiKey && serviceConfig?.apiEndpoint) {
        await this.sendToProvider(orderData, serviceConfig);
      }
      
      return { success: true };
    } catch (error) {
      console.error('Failed to send notification:', error);
      return { success: false, error: error.message };
    }
  }

  private async sendEmailNotification(orderData: OrderNotificationData) {
    const mailOptions = {
      from: process.env.SMTP_USER,
      to: process.env.ADMIN_EMAIL || 'admin@nanuuzystore.com',
      subject: `🛍 Order Baru - ${orderData.packageName}`,
      html: this.generateEmailTemplate(orderData),
    };

    await this.emailTransporter.sendMail(mailOptions);
  }

  private async sendWhatsAppNotification(orderData: OrderNotificationData) {
    // WhatsApp notification using Fonnte API
    const message = this.generateWhatsAppMessage(orderData);
    
    try {
      const response = await fetch('https://api.fonnte.com/send', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${process.env.FONNTE_API_KEY || ''}`,
        },
        body: JSON.stringify({
          target: process.env.ADMIN_WHATSAPP || '6283176771027',
          message: {
            type: 'text',
            text: message
          }
        }),
      });

      if (!response.ok) {
        console.error('Failed to send WhatsApp notification');
      }
    } catch (error) {
      console.error('WhatsApp notification error:', error);
    }
  }

  private async sendToProvider(orderData: OrderNotificationData, serviceConfig: ServiceConfig) {
    try {
      const response = await fetch(serviceConfig.apiEndpoint!, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${serviceConfig.apiKey}`,
        },
        body: JSON.stringify({
          service_id: serviceConfig.serviceId,
          target: orderData.targetUsername,
          quantity: orderData.quantity,
          custom_data: {
            order_id: orderData.orderId,
            package_name: orderData.packageName,
            platform: orderData.platform,
            customer_email: orderData.userEmail,
            customer_name: orderData.userName,
          }
        }),
      });

      if (!response.ok) {
        console.error('Failed to send order to provider');
        throw new Error('Provider API error');
      }

      const result = await response.json();
      console.log('Provider response:', result);
      
      return result;
    } catch (error) {
      console.error('Provider API error:', error);
      throw error;
    }
  }

  private generateEmailTemplate(orderData: OrderNotificationData): string {
    return `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: #000000; padding: 20px; border-radius: 10px;">
          <div style="text-align: center; margin-bottom: 30px;">
            <h1 style="color: #1E90FF; font-size: 28px; margin: 0;">🛍 Order Baru</h1>
            <h2 style="color: #1E90FF; font-size: 20px; margin: 10px 0;">NanuuzyStore Official</h2>
          </div>
          
          <div style="background: #1a1a1a; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
            <h3 style="color: #1E90FF; margin: 0 0 15px 0;">📦 Detail Order</h3>
            
            <table style="width: 100%; border-collapse: collapse;">
              <tr>
                <td style="color: #87CEEB; padding: 8px; border-bottom: 1px solid #333;">Order ID:</td>
                <td style="color: #ffffff; padding: 8px; border-bottom: 1px solid #333;">#${orderData.orderId.slice(-8)}</td>
              </tr>
              <tr>
                <td style="color: #87CEEB; padding: 8px; border-bottom: 1px solid #333;">Paket:</td>
                <td style="color: #ffffff; padding: 8px; border-bottom: 1px solid #333;">${orderData.packageName}</td>
              </tr>
              <tr>
                <td style="color: #87CEEB; padding: 8px; border-bottom: 1px solid #333;">Platform:</td>
                <td style="color: #ffffff; padding: 8px; border-bottom: 1px solid #333;">${orderData.platform}</td>
              </tr>
              <tr>
                <td style="color: #87CEEB; padding: 8px; border-bottom: 1px solid #333;">Target:</td>
                <td style="color: #ffffff; padding: 8px; border-bottom: 1px solid #333;">@${orderData.targetUsername}</td>
              </tr>
              <tr>
                <td style="color: #87CEEB; padding: 8px; border-bottom: 1px solid #333;">Jumlah:</td>
                <td style="color: #ffffff; padding: 8px; border-bottom: 1px solid #333;">${orderData.quantity.toLocaleString()}</td>
              </tr>
              <tr>
                <td style="color: #87CEEB; padding: 8px;">Harga:</td>
                <td style="color: #ffffff; padding: 8px;">Rp ${orderData.price.toLocaleString('id-ID')}</td>
              </tr>
            </table>
          </div>
          
          <div style="background: #1a1a1a; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
            <h3 style="color: #1E90FF; margin: 0 0 15px 0;">👤 Informasi Customer</h3>
            
            <table style="width: 100%; border-collapse: collapse;">
              <tr>
                <td style="color: #87CEEB; padding: 8px; border-bottom: 1px solid #333;">Nama:</td>
                <td style="color: #ffffff; padding: 8px; border-bottom: 1px solid #333;">${orderData.userName || 'Tidak ada nama'}</td>
              </tr>
              <tr>
                <td style="color: #87CEEB; padding: 8px; border-bottom: 1px solid #333;">Email:</td>
                <td style="color: #ffffff; padding: 8px; border-bottom: 1px solid #333;">${orderData.userEmail}</td>
              </tr>
            </table>
          </div>
          
          <div style="text-align: center; margin-top: 30px;">
            <p style="color: #87CEEB; font-size: 14px;">
              📱 Hubungi: <a href="https://wa.me/6283176771027" style="color: #1E90FF; text-decoration: none;">0831-7677-1027</a>
            </p>
            <p style="color: #87CEEB; font-size: 12px; margin-top: 10px;">
              © 2024 NanuuzyStore Official - Platform Reseller Followers Terpercaya
            </p>
          </div>
        </div>
      </div>
    `;
  }

  private generateWhatsAppMessage(orderData: OrderNotificationData): string {
    return `🛍 *ORDER BARU - NANUUYSTORE OFFICIAL* 🛍

📦 *Detail Order:*
🔹 Order ID: #${orderData.orderId.slice(-8)}
🔹 Paket: ${orderData.packageName}
🔹 Platform: ${orderData.platform}
🔹 Target: @${orderData.targetUsername}
🔹 Jumlah: ${orderData.quantity.toLocaleString()}
🔹 Harga: Rp ${orderData.price.toLocaleString('id-ID')}

👤 *Informasi Customer:*
🔹 Nama: ${orderData.userName || 'Tidak ada nama'}
🔹 Email: ${orderData.userEmail}

📱 *Hubungi Admin:*
🔹 WhatsApp: 0831-7677-1027
🔹 Website: nanuuzystore.com

⏰ *Jam Operasional:*
09:00 - 22:00 WIB

© 2024 NanuuzyStore Official`;
  }
}

export default NotificationService;